#!/bin/bash

##### Constants
JAVA_VERSION=8
JAVA_UPDATE=161
JAVA_BUILD=12
JAVA_GUID="2f38c3b165be4555a1fa6e98c45e0808"
TOMCAT_VERSION_MAJOR=8
TOMCAT_VERSION_FULL=8.5.24


if [ "$1" ]
  then
    JAVA_VERSION="$1"
fi

if [ "$2" ]
  then
    JAVA_UPDATE="$2"
fi

if [ "$3" ]
  then
    JAVA_BUILD="$3"
fi

docker build -f Dockerfile-glibc --rm=true -t dockermaker/alpine-glibc .
docker build -f Dockerfile-java --rm=true \
       --build-arg JAVA_VERSION=${JAVA_VERSION} \
       --build-arg JAVA_UPDATE=${JAVA_UPDATE} \
       --build-arg JAVA_BUILD=${JAVA_BUILD} \
       --build-arg JAVA_GUID=${JAVA_GUID} \
        -t alpine-java:${JAVA_VERSION}u${JAVA_UPDATE} .
docker build -f Dockerfile-tomcat --rm=true \
       --build-arg TOMCAT_VERSION_FULL=${TOMCAT_VERSION_FULL} \
       --build-arg TOMCAT_VERSION_MAJOR=${TOMCAT_VERSION_MAJOR} \
       -t alpine-java-tc:${TOMCAT_VERSION_FULL} .
docker build -f Dockerfile --rm=true \
       -t reqwired-engine .

